const sdk = require('node-appwrite');

module.exports = async function (req, res) {
  // Add some debugging
  console.log('Function called with:');
  console.log('Request keys:', Object.keys(req));
  console.log('Headers:', req.headers);
  console.log('Body type:', typeof req.body);
  console.log('Body content:', req.body);
  console.log('Variables:', req.variables);
  console.log('Environment check:', {
    projectId: process.env.APPWRITE_FUNCTION_PROJECT_ID,
    hasApiKey: !!process.env.APPWRITE_FUNCTION_API_KEY,
    endpoint: process.env.APPWRITE_ENDPOINT
  });
  
  // Initialize Appwrite SDK with function's service role
  // When APPWRITE_FUNCTION_API_KEY is available, the function has its scoped permissions
  const client = new sdk.Client();
  const users = new sdk.Users(client);
  const teams = new sdk.Teams(client);

  // Use the function's API key which has the scopes we defined
  client
    .setEndpoint(process.env.APPWRITE_ENDPOINT || 'https://cloud.appwrite.io/v1')
    .setProject(process.env.APPWRITE_FUNCTION_PROJECT_ID)
    .setKey(process.env.APPWRITE_FUNCTION_API_KEY); // This is automatically provided by Appwrite

  // Parse request body - in Appwrite functions, the body is in req.body or req.variables
  let body;
  try {
    // Try to parse as JSON if it's a string, otherwise use as-is
    if (typeof req.body === 'string') {
      body = JSON.parse(req.body);
    } else if (req.body && typeof req.body === 'object') {
      body = req.body;
    } else if (req.variables) {
      // Fallback to req.variables if body is not available
      body = {
        action: req.variables.action || 'listUsers',
        payload: req.variables.payload ? JSON.parse(req.variables.payload) : {}
      };
    } else {
      // Default to listUsers if no body provided
      body = { action: 'listUsers', payload: {} };
    }
  } catch (error) {
    return res.json({ error: 'Invalid JSON body', details: error.message }, 400);
  }

  const { action, payload = {} } = body;

  // Verify JWT token from request headers (with proper null checks)
  const headers = req.headers || {};
  
  // Try to find JWT in various places
  const jwt = headers['x-appwrite-jwt'] || 
              headers['X-Appwrite-JWT'] || 
              headers['X-APPWRITE-JWT'] ||
              headers['authorization']?.replace('Bearer ', '') ||
              headers['Authorization']?.replace('Bearer ', '') ||
              payload.jwt || // Try payload
              body.jwt; // Try body
  
  // TEMPORARY: Skip JWT validation for debugging
  console.log('JWT search results:', {
    fromHeaders: !!headers['x-appwrite-jwt'] || !!headers['X-Appwrite-JWT'],
    fromAuth: !!headers['authorization'] || !!headers['Authorization'],
    fromPayload: !!payload.jwt,
    fromBody: !!body.jwt,
    finalJwt: !!jwt
  });
  
  if (!jwt) {
    // For now, let's continue without JWT to test the function structure
    console.log('WARNING: Proceeding without JWT for debugging');
    // return res.json({ 
    //   error: 'Unauthorized - JWT token required',
    //   receivedHeaders: headers ? Object.keys(headers) : 'No headers object',
    //   requestKeys: Object.keys(req),
    //   debug: 'No JWT found in headers'
    // }, 401);
  }

  try {
    // Verify the JWT belongs to an admin user using a separate client
    const userClient = new sdk.Client();
    const account = new sdk.Account(userClient);
    const userTeams = new sdk.Teams(userClient);
    
    userClient
      .setEndpoint(process.env.APPWRITE_ENDPOINT || 'https://cloud.appwrite.io/v1')
      .setProject(process.env.APPWRITE_FUNCTION_PROJECT_ID)
      .setJWT(jwt);
    
    // Get current user from JWT
    const currentUser = await account.get();
    
    // Check if user has admin privileges
    const adminTeamId = process.env.ADMIN_TEAM_ID || 'admin';
    try {
      const membership = await userTeams.getMembership(adminTeamId, currentUser.$id);
      if (!membership) {
        return res.json({ error: 'Forbidden - Admin access required' }, 403);
      }
    } catch (error) {
      // User is not in admin team
      return res.json({ error: 'Forbidden - Admin access required' }, 403);
    }

    // Continue using the main client with function's built-in permissions for admin operations

    // Handle different actions
    switch (action) {
      case 'listUsers': {
        const { search, limit = 25, offset = 0, queries = [] } = payload;
        const result = await users.list(queries, search);
        return res.json(result);
      }

      case 'getUser': {
        const { userId } = payload;
        if (!userId) {
          return res.json({ error: 'userId is required' }, 400);
        }
        const user = await users.get(userId);
        return res.json(user);
      }

      case 'createUser': {
        const { email, password, name, phone, labels, emailVerification } = payload;
        if (!email || !password || !name) {
          return res.json({ error: 'email, password, and name are required' }, 400);
        }

        // Generate unique ID
        const userId = sdk.ID.unique();
        
        // Create user
        const user = await users.create(
          userId,
          email,
          phone,
          password,
          name
        );

        // Update labels if provided
        if (labels && labels.length > 0) {
          await users.updateLabels(userId, labels);
        }

        // Update email verification if specified
        if (emailVerification === true) {
          await users.updateEmailVerification(userId, true);
        }

        // Add to teams based on labels
        if (labels && labels.includes('admin')) {
          try {
            await teams.createMembership(
              adminTeamId,
              ['owner'],
              userId,
              email,
              undefined,
              undefined,
              name
            );
          } catch (error) {
            console.error('Failed to add user to admin team:', error);
          }
        }

        if (labels && labels.includes('beta_tester')) {
          try {
            await teams.createMembership(
              'beta_testers',
              ['member'],
              userId,
              email,
              undefined,
              undefined,
              name
            );
          } catch (error) {
            console.error('Failed to add user to beta_testers team:', error);
          }
        }

        return res.json(user);
      }

      case 'updateUser': {
        const { userId, updates } = payload;
        if (!userId) {
          return res.json({ error: 'userId is required' }, 400);
        }

        let user = await users.get(userId);

        // Update basic fields
        if (updates.name !== undefined) {
          user = await users.updateName(userId, updates.name);
        }
        if (updates.email !== undefined) {
          user = await users.updateEmail(userId, updates.email);
        }
        if (updates.phone !== undefined) {
          user = await users.updatePhone(userId, updates.phone);
        }
        if (updates.labels !== undefined) {
          user = await users.updateLabels(userId, updates.labels);
        }
        if (updates.emailVerification !== undefined) {
          user = await users.updateEmailVerification(userId, updates.emailVerification);
        }
        if (updates.phoneVerification !== undefined) {
          user = await users.updatePhoneVerification(userId, updates.phoneVerification);
        }

        return res.json(user);
      }

      case 'deleteUser': {
        const { userId } = payload;
        if (!userId) {
          return res.json({ error: 'userId is required' }, 400);
        }
        await users.delete(userId);
        return res.json({ success: true });
      }

      case 'updateUserStatus': {
        const { userId, status } = payload;
        if (!userId || status === undefined) {
          return res.json({ error: 'userId and status are required' }, 400);
        }
        const user = await users.updateStatus(userId, status);
        return res.json(user);
      }

      case 'updateUserLabels': {
        const { userId, labels } = payload;
        if (!userId || !labels) {
          return res.json({ error: 'userId and labels are required' }, 400);
        }
        const user = await users.updateLabels(userId, labels);
        return res.json(user);
      }

      case 'updateEmailVerification': {
        const { userId, emailVerification } = payload;
        if (!userId || emailVerification === undefined) {
          return res.json({ error: 'userId and emailVerification are required' }, 400);
        }
        const user = await users.updateEmailVerification(userId, emailVerification);
        return res.json(user);
      }

      case 'resetUserPassword': {
        const { userId } = payload;
        if (!userId) {
          return res.json({ error: 'userId is required' }, 400);
        }
        // Generate a new random password
        const newPassword = generateRandomPassword();
        const user = await users.updatePassword(userId, newPassword);
        
        // In production, you'd want to send this password to the user via email
        // For now, we'll return it in the response (only for development)
        return res.json({ 
          user, 
          temporaryPassword: newPassword,
          message: 'Password reset successfully. Please share the temporary password with the user securely.'
        });
      }

      case 'updateTeamMembership': {
        const { userId, teamId, add } = payload;
        if (!userId || !teamId || add === undefined) {
          return res.json({ error: 'userId, teamId, and add are required' }, 400);
        }

        try {
          if (add) {
            // Get user details first
            const user = await users.get(userId);
            // Add user to team
            await teams.createMembership(
              teamId,
              ['member'],
              userId,
              user.email,
              undefined,
              undefined,
              user.name
            );
          } else {
            // Remove user from team
            // First, we need to find the membership
            const memberships = await teams.listMemberships(teamId);
            const membership = memberships.memberships.find(m => m.userId === userId);
            if (membership) {
              await teams.deleteMembership(teamId, membership.$id);
            }
          }
          return res.json({ success: true });
        } catch (error) {
          return res.json({ error: error.message }, 400);
        }
      }

      case 'getUserSessions': {
        const { userId } = payload;
        if (!userId) {
          return res.json({ error: 'userId is required' }, 400);
        }
        const sessions = await users.listSessions(userId);
        return res.json(sessions);
      }

      case 'deleteUserSessions': {
        const { userId } = payload;
        if (!userId) {
          return res.json({ error: 'userId is required' }, 400);
        }
        await users.deleteSessions(userId);
        return res.json({ success: true });
      }

      default:
        return res.json({ error: `Unknown action: ${action}` }, 400);
    }
  } catch (error) {
    console.error('Function error:', error);
    return res.json({ 
      error: error.message || 'Internal server error',
      details: error.response || undefined
    }, error.code || 500);
  }
};

// Helper function to generate a random password
function generateRandomPassword() {
  const length = 12;
  const charset = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*';
  let password = '';
  for (let i = 0; i < length; i++) {
    password += charset.charAt(Math.floor(Math.random() * charset.length));
  }
  return password;
}