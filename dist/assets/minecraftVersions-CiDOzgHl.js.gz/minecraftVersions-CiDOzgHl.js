import{m as a}from"./index-KCZmE9lu.js";/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const t=[["rect",{width:"7",height:"7",x:"14",y:"3",rx:"1",key:"6d4xhi"}],["path",{d:"M10 21V8a1 1 0 0 0-1-1H4a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-5a1 1 0 0 0-1-1H3",key:"1fpvtg"}]],l=a("blocks",t);/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const e=[["path",{d:"M12 20v2",key:"1lh1kg"}],["path",{d:"M12 2v2",key:"tus03m"}],["path",{d:"M17 20v2",key:"1rnc9c"}],["path",{d:"M17 2v2",key:"11trls"}],["path",{d:"M2 12h2",key:"1t8f8n"}],["path",{d:"M2 17h2",key:"7oei6x"}],["path",{d:"M2 7h2",key:"asdhe0"}],["path",{d:"M20 12h2",key:"1q8mjw"}],["path",{d:"M20 17h2",key:"1fpfkl"}],["path",{d:"M20 7h2",key:"1o8tra"}],["path",{d:"M7 20v2",key:"4gnj0m"}],["path",{d:"M7 2v2",key:"1i4yhu"}],["rect",{x:"4",y:"4",width:"16",height:"16",rx:"2",key:"1vbyd7"}],["rect",{x:"8",y:"8",width:"8",height:"8",rx:"1",key:"z9xiuo"}]],o=a("cpu",e),h=[{value:"All",label:"All Versions",metadata:{compatibility:["forge","fabric","neoforge","quilt"]}},{value:"1.14.4",label:"1.14.4",metadata:{compatibility:["forge"]}},{value:"1.15.2",label:"1.15.2",metadata:{compatibility:["forge"]}},{value:"1.16.5",label:"1.16.5",metadata:{compatibility:["forge"]}},{value:"1.17.1",label:"1.17.1",metadata:{compatibility:["forge"]}},{value:"1.18.2",label:"1.18.2",metadata:{compatibility:["forge","fabric"]}},{value:"1.19.2",label:"1.19.2",metadata:{compatibility:["forge","fabric"]}},{value:"1.20.1",label:"1.20.1",metadata:{compatibility:["forge"]}}];export{l as B,o as C,h as M};
