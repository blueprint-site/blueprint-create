const sdk = require('node-appwrite');
const sharp = require('sharp');

module.exports = async ({ req, res, log, error }) => {
  const client = new sdk.Client()
    .setEndpoint(process.env.APPWRITE_FUNCTION_API_ENDPOINT)
    .setProject(process.env.APPWRITE_FUNCTION_PROJECT_ID)
    .setKey(process.env.APPWRITE_FUNCTION_API_KEY);

  const storage = new sdk.Storage(client);
  const databases = new sdk.Databases(client);

  try {
    const payload = JSON.parse(req.body || '{}');
    const { bucketId, fileId, quality = 85, width, height, preserveOriginal = false } = payload;

    if (!bucketId || !fileId) {
      return res.json({ 
        success: false, 
        error: 'Missing required parameters: bucketId and fileId' 
      }, 400);
    }

    log(`Processing image: ${fileId} from bucket: ${bucketId}`);

    const fileBuffer = await storage.getFileDownload(bucketId, fileId);
    const arrayBuffer = await fileBuffer.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);

    const originalFile = await storage.getFile(bucketId, fileId);
    const originalName = originalFile.name;
    const nameWithoutExt = originalName.substring(0, originalName.lastIndexOf('.')) || originalName;
    
    let sharpInstance = sharp(buffer);
    
    const metadata = await sharpInstance.metadata();
    log(`Original image: ${metadata.width}x${metadata.height}, format: ${metadata.format}`);

    if (width || height) {
      sharpInstance = sharpInstance.resize({
        width: width || null,
        height: height || null,
        fit: 'inside',
        withoutEnlargement: true
      });
    }

    const compressedBuffer = await sharpInstance
      .webp({ 
        quality: Math.min(100, Math.max(1, quality)),
        effort: 6
      })
      .toBuffer();

    const compressedMetadata = await sharp(compressedBuffer).metadata();
    
    const compressionRatio = ((buffer.length - compressedBuffer.length) / buffer.length * 100).toFixed(2);
    log(`Compressed to WebP: ${compressedMetadata.width}x${compressedMetadata.height}, saved ${compressionRatio}%`);

    const permissions = originalFile.permissions || [];
    
    const compressedFile = await storage.createFile(
      bucketId,
      sdk.ID.unique(),
      new sdk.InputFile.fromBuffer(compressedBuffer, `${nameWithoutExt}.webp`),
      permissions
    );

    if (!preserveOriginal) {
      await storage.deleteFile(bucketId, fileId);
      log(`Deleted original file: ${fileId}`);
    }

    const result = {
      success: true,
      original: {
        id: fileId,
        name: originalName,
        size: buffer.length,
        width: metadata.width,
        height: metadata.height,
        format: metadata.format,
        deleted: !preserveOriginal
      },
      compressed: {
        id: compressedFile.$id,
        name: compressedFile.name,
        size: compressedBuffer.length,
        width: compressedMetadata.width,
        height: compressedMetadata.height,
        format: 'webp',
        bucketId: bucketId
      },
      stats: {
        compressionRatio: `${compressionRatio}%`,
        sizeSaved: buffer.length - compressedBuffer.length,
        processingTime: `${Date.now() - startTime}ms`
      }
    };

    if (payload.updateDocument) {
      const { databaseId, collectionId, documentId, attributeName } = payload.updateDocument;
      
      if (databaseId && collectionId && documentId && attributeName) {
        try {
          await databases.updateDocument(
            databaseId,
            collectionId,
            documentId,
            { [attributeName]: compressedFile.$id }
          );
          log(`Updated document ${documentId} with new file ID`);
          result.documentUpdated = true;
        } catch (err) {
          error(`Failed to update document: ${err.message}`);
          result.documentUpdateError = err.message;
        }
      }
    }

    return res.json(result);

  } catch (err) {
    error(`Error processing image: ${err.message}`);
    return res.json({ 
      success: false, 
      error: err.message 
    }, 500);
  }
};

const startTime = Date.now();