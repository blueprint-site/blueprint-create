import{aa as a}from"./index-DqfNU3ry.js";/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const t=[["rect",{width:"7",height:"7",x:"14",y:"3",rx:"1",key:"6d4xhi"}],["path",{d:"M10 21V8a1 1 0 0 0-1-1H4a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-5a1 1 0 0 0-1-1H3",key:"1fpvtg"}]],o=a("blocks",t);/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const e=[["path",{d:"M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z",key:"hh9hay"}],["path",{d:"m3.3 7 8.7 5 8.7-5",key:"g66t2b"}],["path",{d:"M12 22V12",key:"d0xqtd"}]],h=a("box",e);/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const l=[["path",{d:"M12 20v2",key:"1lh1kg"}],["path",{d:"M12 2v2",key:"tus03m"}],["path",{d:"M17 20v2",key:"1rnc9c"}],["path",{d:"M17 2v2",key:"11trls"}],["path",{d:"M2 12h2",key:"1t8f8n"}],["path",{d:"M2 17h2",key:"7oei6x"}],["path",{d:"M2 7h2",key:"asdhe0"}],["path",{d:"M20 12h2",key:"1q8mjw"}],["path",{d:"M20 17h2",key:"1fpfkl"}],["path",{d:"M20 7h2",key:"1o8tra"}],["path",{d:"M7 20v2",key:"4gnj0m"}],["path",{d:"M7 2v2",key:"1i4yhu"}],["rect",{x:"4",y:"4",width:"16",height:"16",rx:"2",key:"1vbyd7"}],["rect",{x:"8",y:"8",width:"8",height:"8",rx:"1",key:"z9xiuo"}]],d=a("cpu",l),c=[{value:"All",label:"All Versions",metadata:{compatibility:["forge","fabric","neoforge","quilt"]}},{value:"1.14.4",label:"1.14.4",metadata:{compatibility:["forge"]}},{value:"1.15.2",label:"1.15.2",metadata:{compatibility:["forge"]}},{value:"1.16.5",label:"1.16.5",metadata:{compatibility:["forge"]}},{value:"1.17.1",label:"1.17.1",metadata:{compatibility:["forge"]}},{value:"1.18.2",label:"1.18.2",metadata:{compatibility:["forge","fabric"]}},{value:"1.19.2",label:"1.19.2",metadata:{compatibility:["forge","fabric"]}},{value:"1.20.1",label:"1.20.1",metadata:{compatibility:["forge","fabric"]}},{value:"1.21.1",label:"1.21.1",metadata:{compatibility:["forge","fabric","neoforge"]}}];export{o as B,d as C,c as M,h as a};
